/** @type import('hardhat/config').HardhatUserConfig */
require("@nomiclabs/hardhat-ethers");

module.exports = {
  solidity: "0.8.27",
  networks: {
    ganache: {
      url: "http://127.0.0.1:7545",
      accounts: [
        "0x704870423453b00704e088161508f2114b1d1aa6d46c5e2e254ba9ef33a34f34", // Private key 2
        "0x69c0b96dbe2dbde65e5cba04f045707bb3f83623ee6ac69de6d105ff1dfb3439"  // Private key 1
      ],
    },
  },
};
